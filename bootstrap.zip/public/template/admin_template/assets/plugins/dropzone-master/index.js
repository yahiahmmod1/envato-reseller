module.exports = require("./lib/dropzone.js"); // Exposing dropzone
